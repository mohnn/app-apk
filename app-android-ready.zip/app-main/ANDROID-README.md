# بناء APK

## الطريقة 1: GitHub Actions (من غير ما تثبت حاجة)
1. ارفع المشروع على GitHub.
2. تبويب Actions > Build Android APK > Run workflow.
3. بعد ما يخلص، نزّل app-debug-apk من Artifacts.

## الطريقة 2: Android Studio
npm install
npm run android:sync
npm run android:open   # ثم Build > Build APK(s)

## ملاحظات
- الكاميرا (QR) مضافة في AndroidManifest وهتطلب إذن عند أول استخدام.
- البيانات في localStorage داخل التطبيق (على الجهاز فقط).
- خط Cairo بيتحمل من الإنترنت؛ للعمل أوفلاين نزّله محلياً.
- لنسخة نشر على Google Play محتاج توقيع (keystore) و assembleRelease.
