package com.modernbritishkids.nursery;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
