import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.modernbritishkids.nursery',
  appName: 'Modern British Kids',
  webDir: 'dist'
};

export default config;
